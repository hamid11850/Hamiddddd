# ساخت Release قابل نصب

برای ساخت Release امضاشده در GitHub، ابتدا یک keystore را یک‌بار بسازید:

```bash
keytool -genkeypair -v -keystore anonymous-sms-release.jks -alias anonymous -keyalg RSA -keysize 2048 -validity 10000
base64 -w 0 anonymous-sms-release.jks > keystore.b64
```

در GitHub Repository → Settings → Secrets and variables → Actions این چهار Secret را بسازید:

- `KEYSTORE_BASE64`: محتوای `keystore.b64`
- `KEYSTORE_PASSWORD`: رمز keystore
- `KEY_ALIAS`: مقدار `anonymous`
- `KEY_PASSWORD`: رمز کلید

سپس از Actions، workflow با نام `Build APK` را روی `workflow_dispatch` اجرا کنید. خروجی درست باید فایل زیر باشد:

```text
anonymous-sms-release.apk
```

فقط همین فایل را روی گوشی نصب کنید، نه فایل ZIP پروژه و نه پوشه Artifact. اگر با زدن فایل هیچ صفحه‌ای باز نمی‌شود، از تنظیمات Android اجازه نصب از همان مرورگر/فایل‌منیجر را فعال کنید و مطمئن شوید فایل با پسوند `.apk` دانلود شده است.

کلید keystore را گم نکنید؛ برای به‌روزرسانی‌های بعدی همین کلید لازم است.
