# راهنمای انتشار Release و امضای APK

## نسخه فعلی
- versionName: 1.0.0
- versionCode: 1

برای نسخه بعدی فقط این دو مقدار را در `android/app/build.gradle.kts` افزایش دهید.

## ساخت کلید امضا (یک‌بار)

روی کامپیوتر یا Termux:

```bash
keytool -genkey -v -keystore anonymous-sms.jks -keyalg RSA -keysize 2048 -validity 10000 -alias anonymous
```

رمزها را یادداشت کنید.

## آماده‌سازی برای GitHub Actions

1. کلید را base64 کنید:
```bash
base64 -w 0 anonymous-sms.jks > keystore.b64
```

2. در GitHub → Settings → Secrets and variables → Actions این Secrets را اضافه کنید:
   - `KEYSTORE_BASE64` : محتوای فایل keystore.b64
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS` : anonymous
   - `KEY_PASSWORD`

3. workflow را دستی یا با پوش اجرا کنید. Artifact با نام app-release دانلود کنید.

## انتشار در GitHub Releases

پس از ساخت موفق:
- به تب Releases بروید
- Draft a new release
- APK را آپلود کنید
- تگ مثل v1.0.0 بزنید

## نکات امنیتی
- هرگز keystore و رمزها را در مخزن عمومی قرار ندهید.
- فایل `.env` و کلید API کاپنل را هم در گیت کامیت نکنید.
