# راهنمای اجرا در Termux

## ۱. نصب پیش‌نیازها

```bash
pkg update -y
pkg install -y git python openjdk-17 wget curl
```

یا:

```bash
bash scripts/termux/install-deps.sh
```

## ۲. دریافت پروژه

```bash
git clone https://github.com/hamid11850/Anonymous-SMS.git
cd Anonymous-SMS
```

## ۳. راه‌اندازی بک‌اند

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# فایل .env را با nano ویرایش کنید و IPPANEL_API_KEY را بگذارید
nano .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## ۴. ساخت APK

ساخت کامل APK روی گوشی با Termux سنگین و زمان‌بر است.
پیشنهاد قوی: از GitHub Actions استفاده کنید (پوش به main → Artifact دانلود).

اگر حتماً محلی می‌خواهید، Android SDK را جداگانه نصب کنید (توصیه نمی‌شود روی گوشی معمولی).

## ۵. پشتیبان‌گیری

```bash
cd ..
zip -r Anonymous-SMS-backup-$(date +%Y%m%d).zip Anonymous-SMS
```
