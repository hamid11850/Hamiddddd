package com.anonymoussms.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import com.anonymoussms.app.R
import com.anonymoussms.app.network.BuyRequest
import com.anonymoussms.app.network.PackageItem
import com.anonymoussms.app.network.RetrofitClient
import com.anonymoussms.app.utils.Prefs
import kotlinx.coroutines.launch

class PackagesActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var recycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_packages)
        prefs = Prefs(this)
        recycler = findViewById(R.id.recyclerPackages)
        recycler.layoutManager = LinearLayoutManager(this)
        loadPackages()
    }

    private fun loadPackages() {
        lifecycleScope.launch {
            try {
                val list = RetrofitClient.api.packages()
                recycler.adapter = PackageAdapter(list) { pkg -> buy(pkg) }
            } catch (e: Exception) {
                Toast.makeText(this@PackagesActivity, "خطا: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun buy(pkg: PackageItem) {
        val token = prefs.token ?: return
        lifecycleScope.launch {
            try {
                val resp = RetrofitClient.api.buy("Bearer $token", BuyRequest(pkg.id))
                if (resp.success) {
                    prefs.credit = resp.new_credit
                    Toast.makeText(this@PackagesActivity, resp.message, Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    Toast.makeText(this@PackagesActivity, resp.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@PackagesActivity, "خطا: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    class PackageAdapter(
        private val items: List<PackageItem>,
        private val onBuy: (PackageItem) -> Unit
    ) : RecyclerView.Adapter<PackageAdapter.VH>() {
        class VH(val view: android.view.View) : RecyclerView.ViewHolder(view) {
            val title: TextView = view.findViewById(R.id.tvTitle)
            val price: TextView = view.findViewById(R.id.tvPrice)
            val btn: TextView = view.findViewById(R.id.btnBuy)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_package, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.title.text = item.title
            holder.price.text = "${item.price_toman} تومان"
            holder.btn.setOnClickListener { onBuy(item) }
        }

        override fun getItemCount() = items.size
    }
}
