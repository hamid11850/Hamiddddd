package com.anonymoussms.app.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.anonymoussms.app.databinding.ActivityMainBinding
import com.anonymoussms.app.network.RetrofitClient
import com.anonymoussms.app.network.SendRequest
import com.anonymoussms.app.utils.Prefs
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: Prefs
    private var smsCount = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = Prefs(this)

        if (!prefs.isLoggedIn) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        updateCreditUI()
        setupListeners()
        refreshCreditFromServer()
    }

    private fun updateCreditUI() {
        val c = prefs.credit
        binding.tvCredit.text = "اعتبار پیامک $c عدد"
        binding.tvCreditBadge.text = "$c عدد"
    }

    private fun setupListeners() {
        binding.etMessage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val len = s?.length ?: 0
                binding.tvCharCount.text = "$len/۳۳۵"
            }
        })

        binding.btnPlus.setOnClickListener {
            if (smsCount < 10) {
                smsCount++
                binding.tvCount.text = smsCount.toString()
            }
        }
        binding.btnMinus.setOnClickListener {
            if (smsCount > 1) {
                smsCount--
                binding.tvCount.text = smsCount.toString()
            }
        }

        binding.btnSend.setOnClickListener { sendSms() }
        binding.btnSupport.setOnClickListener {
            Toast.makeText(this, "پشتیبانی: از طریق تلگرام یا تیکت در پنل", Toast.LENGTH_LONG).show()
        }
        binding.btnCart.setOnClickListener {
            startActivity(Intent(this, PackagesActivity::class.java))
        }
        binding.tvCredit.setOnClickListener {
            startActivity(Intent(this, PackagesActivity::class.java))
        }
    }

    private fun refreshCreditFromServer() {
        val token = prefs.token ?: return
        lifecycleScope.launch {
            try {
                val user = RetrofitClient.api.me("Bearer $token")
                prefs.credit = user.credit
                updateCreditUI()
            } catch (_: Exception) {
                // آفلاین یا خطا — از کش استفاده می‌کنیم
            }
        }
    }

    private fun sendSms() {
        val phone = binding.etPhone.text.toString().trim()
        val message = binding.etMessage.text.toString().trim()

        if (!phone.matches(Regex("^09\\d{9}$"))) {
            Toast.makeText(this, "شماره موبایل معتبر وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        if (message.isEmpty()) {
            Toast.makeText(this, "متن پیام را وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }

        val token = prefs.token
        if (token.isNullOrBlank()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        binding.btnSend.isEnabled = false
        binding.btnSend.text = "در حال ارسال..."

        lifecycleScope.launch {
            try {
                val resp = RetrofitClient.api.sendSms(
                    "Bearer $token",
                    SendRequest(recipient = phone, message = message, count = smsCount)
                )
                if (resp.success) {
                    prefs.credit = resp.remaining_credit
                    updateCreditUI()
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("ارسال موفق")
                        .setMessage(resp.message + "\nهزینه: ${resp.cost} سکه")
                        .setPositiveButton("باشه", null)
                        .show()
                    binding.etMessage.setText("")
                } else {
                    Toast.makeText(this@MainActivity, resp.message, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "خطا در ارتباط با سرور: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                binding.btnSend.isEnabled = true
                binding.btnSend.text = getString(com.anonymoussms.app.R.string.send)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateCreditUI()
        refreshCreditFromServer()
    }
}
