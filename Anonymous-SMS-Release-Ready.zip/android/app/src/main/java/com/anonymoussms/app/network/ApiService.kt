package com.anonymoussms.app.network

import retrofit2.http.*

data class LoginRequest(val phone: String, val password: String)
data class RegisterRequest(val phone: String, val password: String, val full_name: String? = null)
data class TokenResponse(val access_token: String, val token_type: String, val credit: Int)
data class UserResponse(val id: Int, val phone: String, val full_name: String?, val credit: Int, val is_admin: Boolean)
data class SendRequest(val recipient: String, val message: String, val count: Int = 1)
data class SendResponse(
    val success: Boolean,
    val message: String,
    val cost: Int = 0,
    val remaining_credit: Int = 0,
    val outbox_ids: List<String> = emptyList()
)
data class PackageItem(val id: String, val title: String, val sms_count: Int, val price_toman: Int)
data class BuyRequest(val package_id: String)
data class BuyResponse(val success: Boolean, val message: String, val new_credit: Int)

interface ApiService {
    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): TokenResponse

    @POST("auth/register")
    suspend fun register(@Body body: RegisterRequest): TokenResponse

    @GET("me")
    suspend fun me(@Header("Authorization") token: String): UserResponse

    @POST("sms/send")
    suspend fun sendSms(
        @Header("Authorization") token: String,
        @Body body: SendRequest
    ): SendResponse

    @GET("packages")
    suspend fun packages(): List<PackageItem>

    @POST("buy")
    suspend fun buy(
        @Header("Authorization") token: String,
        @Body body: BuyRequest
    ): BuyResponse
}
