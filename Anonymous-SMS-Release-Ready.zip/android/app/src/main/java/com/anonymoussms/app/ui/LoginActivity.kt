package com.anonymoussms.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.anonymoussms.app.databinding.ActivityLoginBinding
import com.anonymoussms.app.network.LoginRequest
import com.anonymoussms.app.network.RegisterRequest
import com.anonymoussms.app.network.RetrofitClient
import com.anonymoussms.app.utils.Prefs
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = Prefs(this)

        binding.btnLogin.setOnClickListener { doLogin() }
        binding.btnRegister.setOnClickListener { doRegister() }
    }

    private fun doLogin() {
        val phone = binding.etPhone.text.toString().trim()
        val pass = binding.etPassword.text.toString()
        if (!phone.matches(Regex("^09\\d{9}$")) || pass.length < 4) {
            Toast.makeText(this, "شماره و رمز را صحیح وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            try {
                val resp = RetrofitClient.api.login(LoginRequest(phone, pass))
                prefs.token = resp.access_token
                prefs.credit = resp.credit
                prefs.phone = phone
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "ورود ناموفق: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun doRegister() {
        val phone = binding.etPhone.text.toString().trim()
        val pass = binding.etPassword.text.toString()
        if (!phone.matches(Regex("^09\\d{9}$")) || pass.length < 4) {
            Toast.makeText(this, "شماره و رمز (حداقل ۴ کاراکتر) را وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            try {
                val resp = RetrofitClient.api.register(RegisterRequest(phone, pass))
                prefs.token = resp.access_token
                prefs.credit = resp.credit
                prefs.phone = phone
                Toast.makeText(this@LoginActivity, "ثبت‌نام موفق — ۵ پیامک هدیه", Toast.LENGTH_LONG).show()
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "ثبت‌نام ناموفق: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
