#!/data/data/com.termux/files/usr/bin/bash
# کلون پروژه از GitHub

REPO_URL="${1:-https://github.com/hamid11850/Anonymous-SMS.git}"

echo "در حال کلون از: $REPO_URL"
git clone "$REPO_URL"
cd Anonymous-SMS || exit 1
echo "پروژه کلون شد. مسیر: $(pwd)"
echo "برای راه‌اندازی بک‌اند:"
echo "  cd backend && python -m venv venv && source venv/bin/activate && pip install -r requirements.txt"
