#!/data/data/com.termux/files/usr/bin/bash
# نصب پیش‌نیازهای Termux برای مدیریت پروژه

set -e
echo "=== نصب پیش‌نیازهای Termux ==="

pkg update -y
pkg install -y git python openjdk-17 wget curl unzip

# Gradle (اختیاری - برای ساخت محلی روی گوشی سنگین است)
# پیشنهاد: ساخت APK را روی GitHub Actions انجام دهید

echo ""
echo "پیش‌نیازها نصب شدند."
echo "برای کلون پروژه:"
echo "  bash scripts/termux/clone-project.sh"
