# سامانه ارسال پیامک ناشناس (Anonymous SMS)

پروژه کامل اپلیکیشن اندروید + بک‌اند برای ارسال پیامک ناشناس با سیستم اعتبار (سکه)، کیف پول و اتصال به پنل کاپنل (KPanel / IPPanel Edge).

## ساختار پروژه

```
Anonymous-SMS/
├── android/                 # پروژه کامل اندروید (Gradle)
├── backend/                 # بک‌اند FastAPI (Python)
├── docs/                    # مستندات فارسی
├── scripts/termux/          # اسکریپت‌های Termux
├── .github/workflows/       # GitHub Actions برای ساخت APK
└── README.md
```

## ویژگی‌ها

- رابط کاربری مطابق اسکرین‌شات ارائه‌شده
- سیستم اعتبار پیامک (سکه)
- ارسال پیامک از طریق API کاپنل (IPPanel Edge v1)
- احراز هویت کاربر
- پنل مدیریت ساده
- ساخت خودکار APK با GitHub Actions
- پشتیبانی کامل از Termux برای مدیریت و ساخت

## پیش‌نیازها

### برای توسعه اندروید
- Android Studio Hedgehog یا جدیدتر
- JDK 17+
- Android SDK 34

### برای بک‌اند
- Python 3.11+
- pip

### کلید API کاپنل
کلید دسترسی را از پنل کاپنل (بخش برنامه‌نویسان ← کلیدهای دسترسی) بگیرید و در فایل `.env` بک‌اند قرار دهید.

## راه‌اندازی سریع بک‌اند

```bash
cd backend
python -m venv venv
source venv/bin/activate   # در ویندوز: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# فایل .env را ویرایش کنید و IPPANEL_API_KEY را وارد کنید
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## ساخت APK با GitHub Actions

پس از پوش کردن پروژه به GitHub، Actions به صورت خودکار APK را می‌سازد و به عنوان Artifact ذخیره می‌کند.

برای امضای Release، کلید keystore را به عنوان Secret در GitHub اضافه کنید (راهنما در `docs/RELEASE.md`).

## اجرا در Termux

راهنمای کامل در `docs/TERMUX.md` و اسکریپت‌های آماده در `scripts/termux/`.

## مجوز

این پروژه برای استفاده شخصی و تجاری مجاز است. مسئولیت استفاده از سرویس پیامک بر عهده کاربر است.
