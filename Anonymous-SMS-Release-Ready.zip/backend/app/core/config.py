from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    IPPANEL_API_KEY: str = ""
    IPPANEL_FROM_NUMBER: str = "+983000505"
    SECRET_KEY: str = "change-me-in-production-please-use-long-random-string"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    DATABASE_URL: str = "sqlite+aiosqlite:///./anonymous_sms.db"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    DEMO_PAYMENTS: bool = False
    SMS_COST_PER_PART: int = 1

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
