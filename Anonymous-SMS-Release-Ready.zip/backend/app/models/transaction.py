from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.sql import func
from app.core.database import Base


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Integer, nullable=False)  # تعداد سکه (مثبت = خرید، منفی = مصرف)
    type = Column(String(50), nullable=False)  # buy, send, admin_adjust
    description = Column(String(255), nullable=True)
    reference = Column(String(100), nullable=True)  # کد پیگیری پرداخت یا outbox_id
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class SmsLog(Base):
    __tablename__ = "sms_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    recipient = Column(String(20), nullable=False)
    message = Column(Text, nullable=False)
    parts = Column(Integer, default=1)
    cost = Column(Integer, default=1)
    status = Column(String(50), default="pending")  # pending, sent, failed
    outbox_id = Column(String(100), nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
