from pydantic import BaseModel, Field, field_validator
from typing import Optional, List
from datetime import datetime
import re


class UserCreate(BaseModel):
    phone: str
    password: str
    full_name: Optional[str] = None

    @field_validator("phone")
    @classmethod
    def validate_phone(cls, v: str) -> str:
        v = v.strip().replace(" ", "")
        if not re.match(r"^09\d{9}$", v):
            raise ValueError("شماره موبایل باید با ۰۹ شروع شود و ۱۱ رقم باشد")
        return v


class UserLogin(BaseModel):
    phone: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    credit: int = 0


class UserOut(BaseModel):
    id: int
    phone: str
    full_name: Optional[str]
    credit: int
    is_admin: bool
    created_at: Optional[datetime]

    class Config:
        from_attributes = True


class SendSmsRequest(BaseModel):
    recipient: str = Field(..., description="شماره گیرنده مثل ۰۹۱۲۳۴۵۶۷۸۹")
    message: str = Field(..., min_length=1, max_length=1000)
    count: int = Field(1, ge=1, le=10, description="تعداد دفعات ارسال")

    @field_validator("recipient")
    @classmethod
    def validate_recipient(cls, v: str) -> str:
        v = v.strip().replace(" ", "")
        if not re.match(r"^09\d{9}$", v):
            raise ValueError("شماره گیرنده نامعتبر است")
        return v


class SendSmsResponse(BaseModel):
    success: bool
    message: str
    cost: int = 0
    remaining_credit: int = 0
    outbox_ids: List[str] = []


class CreditPackage(BaseModel):
    id: str
    title: str
    sms_count: int
    price_toman: int


class BuyPackageRequest(BaseModel):
    package_id: str


# بسته فروش اصلی؛ اتصال پرداخت واقعی در نسخه انتشار انجام می‌شود.
DEFAULT_PACKAGES = [
    CreditPackage(id="sms30", title="بسته محبوب؛ ۳۰ پیامک", sms_count=30, price_toman=190000),
]
