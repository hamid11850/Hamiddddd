import httpx
from typing import List, Optional, Dict, Any
from app.core.config import get_settings

settings = get_settings()
BASE_URL = "https://edge.ippanel.com/v1"


class KPanelService:
    def __init__(self):
        self.api_key = settings.IPPANEL_API_KEY
        self.from_number = settings.IPPANEL_FROM_NUMBER
        self.headers = {
            "Authorization": self.api_key,
            "Content-Type": "application/json",
        }

    async def get_credit(self) -> Optional[float]:
        """اعتبار حساب کاپنل را برمی‌گرداند"""
        if not self.api_key:
            return None
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                resp = await client.get(
                    f"{BASE_URL}/api/payment/credit/mine",
                    headers=self.headers,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return data.get("data", {}).get("credit")
            except Exception:
                return None
        return None

    async def send_sms(
        self,
        recipients: List[str],
        message: str,
        from_number: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        ارسال پیامک عادی (webservice)
        شماره‌ها باید به فرمت بین‌المللی باشند مثل +98912...
        """
        if not self.api_key:
            return {
                "success": False,
                "error": "IPPANEL_API_KEY تنظیم نشده است",
            }

        # نرمال‌سازی شماره‌ها
        normalized = []
        for r in recipients:
            r = r.strip().replace(" ", "")
            if r.startswith("09"):
                r = "+98" + r[1:]
            elif r.startswith("9") and len(r) == 10:
                r = "+98" + r
            elif not r.startswith("+"):
                r = "+98" + r
            normalized.append(r)

        payload = {
            "sending_type": "webservice",
            "from_number": from_number or self.from_number,
            "message": message,
            "params": {
                "recipients": normalized,
            },
        }

        async with httpx.AsyncClient(timeout=45.0) as client:
            try:
                resp = await client.post(
                    f"{BASE_URL}/api/send",
                    headers=self.headers,
                    json=payload,
                )
                data = resp.json()
                meta = data.get("meta", {})
                if resp.status_code in (200, 201) and meta.get("status"):
                    return {
                        "success": True,
                        "outbox_ids": data.get("data", {}).get("message_outbox_ids", []),
                        "raw": data,
                    }
                return {
                    "success": False,
                    "error": meta.get("message", "خطای ناشناخته از کاپنل"),
                    "code": meta.get("message_code"),
                    "raw": data,
                }
            except httpx.TimeoutException:
                return {"success": False, "error": "زمان اتصال به کاپنل به پایان رسید"}
            except Exception as e:
                return {"success": False, "error": str(e)}

    @staticmethod
    def calculate_parts(message: str) -> int:
        """محاسبه تعداد بخش‌های پیامک (تقریبی استاندارد فارسی)"""
        # پیامک فارسی: حدود ۷۰ کاراکتر در بخش اول، ۶۷ در ادامه
        length = len(message)
        if length == 0:
            return 0
        # ساده: هر ۷۰ کاراکتر یک بخش (برای فارسی)
        return max(1, (length + 69) // 70)


kpanel_service = KPanelService()
