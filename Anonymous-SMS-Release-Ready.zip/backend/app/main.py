from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from contextlib import asynccontextmanager

from app.core.config import get_settings
from app.core.database import engine, Base, get_db
from app.core.security import (
    get_password_hash,
    verify_password,
    create_access_token,
    decode_access_token,
)
from app.models.user import User
from app.models.transaction import Transaction, SmsLog
from app.models.schemas import (
    UserCreate,
    UserLogin,
    Token,
    UserOut,
    SendSmsRequest,
    SendSmsResponse,
    BuyPackageRequest,
    DEFAULT_PACKAGES,
)
from app.services.kpanel import kpanel_service

settings = get_settings()
security = HTTPBearer(auto_error=False)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ایجاد جداول
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


app = FastAPI(
    title="سامانه پیامک ناشناس",
    description="API بک‌اند برای اپلیکیشن ارسال پیامک ناشناس",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="توکن احراز هویت لازم است")
    payload = decode_access_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="توکن نامعتبر یا منقضی شده")
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="توکن نامعتبر")
    result = await db.execute(select(User).where(User.id == int(user_id)))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="کاربر یافت نشد یا غیرفعال است")
    return user


@app.get("/")
async def root():
    return {
        "app": "سامانه پیامک ناشناس",
        "version": "1.0.0",
        "docs": "/docs",
    }


@app.post("/auth/register", response_model=Token)
async def register(data: UserCreate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.phone == data.phone))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="این شماره قبلاً ثبت شده است")
    user = User(
        phone=data.phone,
        hashed_password=get_password_hash(data.password),
        full_name=data.full_name,
        credit=5,  # هدیه اولیه ۵ پیامک
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    token = create_access_token({"sub": str(user.id)})
    return Token(access_token=token, credit=user.credit)


@app.post("/auth/login", response_model=Token)
async def login(data: UserLogin, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.phone == data.phone))
    user = result.scalar_one_or_none()
    if not user or not user.hashed_password or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="شماره یا رمز عبور اشتباه است")
    token = create_access_token({"sub": str(user.id)})
    return Token(access_token=token, credit=user.credit)


@app.get("/me", response_model=UserOut)
async def get_me(user: User = Depends(get_current_user)):
    return user


@app.get("/packages")
async def list_packages():
    return DEFAULT_PACKAGES


@app.post("/buy", response_model=dict)
async def buy_package(
    data: BuyPackageRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    خرید بسته اعتبار.
    در نسخه فعلی شبیه‌سازی شده است (بدون درگاه واقعی).
    برای اتصال زرین‌پال یا درگاه دیگر، این بخش را توسعه دهید.
    """
    if not settings.DEMO_PAYMENTS:
        raise HTTPException(
            status_code=503,
            detail="درگاه پرداخت هنوز در این محیط فعال نشده است",
        )

    pkg = next((p for p in DEFAULT_PACKAGES if p.id == data.package_id), None)
    if not pkg:
        raise HTTPException(status_code=404, detail="بسته یافت نشد")

    # شبیه‌سازی پرداخت موفق
    user.credit += pkg.sms_count
    tx = Transaction(
        user_id=user.id,
        amount=pkg.sms_count,
        type="buy",
        description=f"خرید بسته {pkg.title}",
        reference=f"SIM-{pkg.id}-{user.id}",
    )
    db.add(tx)
    await db.commit()
    await db.refresh(user)
    return {
        "success": True,
        "message": f"{pkg.sms_count} پیامک به اعتبار شما اضافه شد",
        "new_credit": user.credit,
        "note": "این خرید شبیه‌سازی شده است. برای پرداخت واقعی درگاه را متصل کنید.",
    }


@app.post("/sms/send", response_model=SendSmsResponse)
async def send_sms(
    data: SendSmsRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    parts = kpanel_service.calculate_parts(data.message)
    total_cost = parts * data.count * settings.SMS_COST_PER_PART

    if user.credit < total_cost:
        raise HTTPException(
            status_code=402,
            detail=f"اعتبار کافی نیست. نیاز به {total_cost} سکه دارید. اعتبار فعلی: {user.credit}",
        )

    # ارسال واقعی از طریق کاپنل
    all_outbox = []
    last_error = None
    success_count = 0

    for _ in range(data.count):
        result = await kpanel_service.send_sms(
            recipients=[data.recipient],
            message=data.message,
        )
        if result.get("success"):
            success_count += 1
            ids = result.get("outbox_ids") or []
            all_outbox.extend([str(i) for i in ids])
        else:
            last_error = result.get("error", "خطای ارسال")

    if success_count == 0:
        # هیچ ارسالی موفق نبود
        log = SmsLog(
            user_id=user.id,
            recipient=data.recipient,
            message=data.message,
            parts=parts,
            cost=0,
            status="failed",
            error_message=last_error,
        )
        db.add(log)
        await db.commit()
        return SendSmsResponse(
            success=False,
            message=last_error or "ارسال ناموفق",
            remaining_credit=user.credit,
        )

    # کسر اعتبار فقط برای ارسال‌های موفق
    actual_cost = parts * success_count * settings.SMS_COST_PER_PART
    user.credit -= actual_cost

    log = SmsLog(
        user_id=user.id,
        recipient=data.recipient,
        message=data.message,
        parts=parts,
        cost=actual_cost,
        status="sent",
        outbox_id=",".join(all_outbox) if all_outbox else None,
    )
    db.add(log)

    tx = Transaction(
        user_id=user.id,
        amount=-actual_cost,
        type="send",
        description=f"ارسال {success_count} پیامک به {data.recipient}",
        reference=",".join(all_outbox) if all_outbox else None,
    )
    db.add(tx)
    await db.commit()
    await db.refresh(user)

    msg = f"{success_count} پیامک با موفقیت ارسال شد"
    if success_count < data.count:
        msg += f" ({data.count - success_count} ناموفق)"

    return SendSmsResponse(
        success=True,
        message=msg,
        cost=actual_cost,
        remaining_credit=user.credit,
        outbox_ids=all_outbox,
    )


@app.get("/sms/history")
async def sms_history(
    limit: int = 20,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(SmsLog)
        .where(SmsLog.user_id == user.id)
        .order_by(SmsLog.created_at.desc())
        .limit(limit)
    )
    logs = result.scalars().all()
    return [
        {
            "id": l.id,
            "recipient": l.recipient,
            "message": l.message[:50] + ("..." if len(l.message) > 50 else ""),
            "parts": l.parts,
            "cost": l.cost,
            "status": l.status,
            "created_at": l.created_at,
        }
        for l in logs
    ]


@app.get("/admin/kpanel-credit")
async def admin_kpanel_credit(user: User = Depends(get_current_user)):
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="دسترسی ادمین لازم است")
    credit = await kpanel_service.get_credit()
    return {"kpanel_credit": credit}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
